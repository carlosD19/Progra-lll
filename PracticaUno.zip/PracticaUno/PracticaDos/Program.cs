﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PracticaDos
{
    class Program
    {
        static void Main(string[] args)
        {
            Operaciones2 parteDos = new Operaciones2();
            parteDos.Opciones();
        }
    }
}
