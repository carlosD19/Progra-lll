﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DemoCapasDAL;
using DemoCapasENT;

namespace DemoCapasBOL
{
    public class UsuarioBOL
    {
        private UsuarioDAL dal;

        public UsuarioBOL()
        {
            dal = new UsuarioDAL();
        }
        public List<EUsuario> Prueba()
        {          
            return dal.CargarTodo();
        }

        public EUsuario Login(EUsuario usuario)
        {
            if (String.IsNullOrEmpty(usuario.Usuario) || String.IsNullOrEmpty(usuario.Email))
            {
                return null;
            }

            if (String.IsNullOrEmpty(usuario.Password))
            {
                return null;
            }

            if (usuario.Password.Length < 5)
            {
                return null;
            }
            return dal.Verificar(usuario);
        }
    }
}
