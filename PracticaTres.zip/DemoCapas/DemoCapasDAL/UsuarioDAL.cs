﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DemoCapasENT;
using Npgsql;

namespace DemoCapasDAL
{
    public class UsuarioDAL
    {
        public List<EUsuario> CargarTodo()
        {
            List<EUsuario> usuarios = new List<EUsuario>();
            using (NpgsqlConnection con = new NpgsqlConnection(Configuracion.ConStr))
            {
                //Abrir una conexion
                con.Open();
                //Definir la consulta
                string sql = @"select id, cedula, usuario,
                               nombre, apellido_uno, apellido_dos,
                               pass, email from usuario";
                NpgsqlCommand cmd = new NpgsqlCommand(sql, con);
                NpgsqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    usuarios.Add(CargarUsuario(reader));
                }
            }

            return usuarios;
        }

        public EUsuario Verificar(EUsuario usuario)
        {
            List<EUsuario> usuarios = new List<EUsuario>();
            using (NpgsqlConnection con = new NpgsqlConnection(Configuracion.ConStr))
            {
                //Abrir una conexion
                con.Open();
                //Definir la consulta
                string sql = @"select id, cedula, usuario,
                               nombre, apellido_uno, apellido_dos,
                               pass, email from usuario where (usuario = @usuario or email = @email and pass = @pass)";
                NpgsqlCommand cmd = new NpgsqlCommand(sql, con);
                cmd.Parameters.AddWithValue("@usuario", usuario.Usuario);
                cmd.Parameters.AddWithValue("@email", usuario.Email);
                cmd.Parameters.AddWithValue("@pass", usuario.Password);

                NpgsqlDataReader reader = cmd.ExecuteReader();

                if (reader.Read())
                {
                    return CargarUsuario(reader);
                }

            }
            return null;
        }

        private EUsuario CargarUsuario(NpgsqlDataReader reader)
        {
            EUsuario usu = new EUsuario();
            usu.Id = Convert.ToInt32(reader["id"]);
            usu.Cedula = reader["cedula"].ToString();
            usu.Usuario = reader["usuario"].ToString();
            usu.Nombre = reader["nombre"].ToString();
            usu.ApellidoUno = reader["apellido_uno"].ToString();
            usu.ApellidoDos = reader["apellido_dos"].ToString();
            usu.Password = reader["pass"].ToString();
            usu.Email = reader["email"].ToString();
            return usu;
        }
    }
}
