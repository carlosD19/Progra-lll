﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace DemoCapasENL
{
    class Imagen
    {
        public int Id { get; set; }
        public int Id_usuario { get; set; }
        public Image Image { get; set; }
    }
}
