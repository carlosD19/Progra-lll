﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cartas
{
    public partial class Form1 : Form
    {
        private Mazo mazo;

        public Form1()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

            string URL = @"https://deckofcardsapi.com/api/deck/new/shuffle/?deck_count=1";
            string json = new WebClient().DownloadString(URL);
            mazo = JsonConvert.DeserializeObject<Mazo>(json);
            DibujarCarta();
        }

        private void DibujarCarta()
        {
            Carta carta = new Carta();
            string URL = String.Format("https://deckofcardsapi.com/api/deck/{0}/draw/?count=1", mazo.deck_id);
            string json = new WebClient().DownloadString(URL);
            carta = JsonConvert.DeserializeObject<Carta>(json);
            pictureBox1.Load(carta.cards[0].image);
            pictureBox1.BorderStyle = BorderStyle.None;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            mazo = new Mazo();
        }
    }
}
