﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Semana2
{
    class Gasolinera
    {
        public double Galones { get; set; }
        public double Precio { get; set; }
        public Gasolinera(double galones)
        {
            Precio = 600;
            Galones = galones;
        }
        public double CalcularPrecio()
        {
            return (Galones * 3.78) * Precio;
        }
    }
}
