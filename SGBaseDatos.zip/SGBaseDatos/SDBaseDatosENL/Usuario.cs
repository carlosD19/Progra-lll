﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SDBaseDatosENL
{
    public static class Usuario
    {
        public static string User { get; set; }
        public static string Pass { get; set; }
        public static bool Activo { get; set; }
    }
}
